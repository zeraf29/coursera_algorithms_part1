/* *****************************************************************************
 *  Name:              JINHYUP KIM
 *  Coursera User ID:  zeraf29@gmail.com
 *  Last modified:     March 22, 2022
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
